namespace ConquerorEngine;

static class Config {
    static public string pathCharacters = @"wwwroot/DB/Characters.json";

    static public string pahtCard = @"wwwroot/DB/Card.json";
    static public string pathImageCharacters = @"Images/Characters";
    static public int basicLife = 30;
}