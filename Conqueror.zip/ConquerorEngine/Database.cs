using System;
using System.IO;
using System.Text.Json;
using System.Collections.Generic;
namespace ConquerorEngine;

static class Database {
    static public List<Card> Cards {
        get; set;
    }
    static public List<string[]> Charact {
        get; set;
    }

    
    static public void LoadCards() {
        if (File.Exists(Config.pahtCard)) {
            string jsonString = File.ReadAllText(Config.pahtCard);
            List<Card> card = JsonSerializer.Deserialize<List<Card>>(jsonString);
        }
    }

    static public void LoadCharacters() {
        if (File.Exists(Config.pathCharacters)) {
            string jsonString = File.ReadAllText(Config.pathCharacters);
            List<Character> characters = JsonSerializer.Deserialize<List<Character>>(jsonString);
        }
    }

    static public void StoreCard(Card card) {
        List<Card>cards = new List<Card>();
        cards.Add(card);
        cards.Add(card);

        var options = new JsonSerializerOptions { WriteIndented = true };
        string jsonString = JsonSerializer.Serialize(cards, options);

        File.WriteAllText(Config.pahtCard, jsonString); 
    }

    static public void StoreCharacter(Character character) {
        List<Character> characters = new List<Character>();
        characters.Add(character);
        characters.Add(character);

        var options = new JsonSerializerOptions { WriteIndented = true };
        string jsonString = JsonSerializer.Serialize(characters, options);
        File.WriteAllText(Config.pathCharacters, jsonString); 
    }
}