Reglas:
- Cada turno el jugador solo puede jugar una carta.
- Cada turno el jugador recibe un punto.
- Cada turno el jugador recibe una carta

Jugador:
- Clase que hereda de Personaje
- Tiene vida.
- Tiene una lista de cartas en la mano.
- Tiene una lista de cartas que puede obtener.
- Tiene puntos.

Carta:
- Tiene un efecto que se interpretara a C#

Parametros para el lenguaje:
- Puntos de vida de cada jugador.
- Cartas que tiene cada jugador en la mano.
- Cartas que tiene cada jugador en la baraja.
- Puntos que tiene cada jugador.

Llamadas desde el frontend al backend sin el lenguaje:
- Mostrar jugadores.
- Selecionar jugadores y empezar el juego.
- Activar efecto de carta y delvolver nuevo estado del juego.