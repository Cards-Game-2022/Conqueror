using System;
namespace ConquerorEngine;

public class Game {
    public Game() {
        Console.WriteLine("hola");
    }

    public void NewGame() {

    }

    public void CreateCard(string name, int cost, string text, string efect, string urlPhoto) {
        Card card = new Card(name, cost, text, efect, 0, urlPhoto);
        Database.StoreCard(card);
        Console.WriteLine("llegue");
    }

    public void UpdateCard(int id, Card card) {

    }

    public void CreateCharacter(string name, string url) {
        Character character = new Character(name, Config.pathImageCharacters + url);

        Database.StoreCharacter(character);
    }
    public void GetCharacter(int id) {
        Database.LoadCharacters();
    } 

    public void GetCard(int id) {

    }
}