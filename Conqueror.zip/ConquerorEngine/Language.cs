namespace ConquerorEngine;

static class Language {

    // valida si el efecto esta escrito correctamente
    static public void IsValid(string efect) {

    }

    // interpreta el efecto y devuelve el nuevo estado del tablero
    static public void Interpreter(string efect) {

    }
}